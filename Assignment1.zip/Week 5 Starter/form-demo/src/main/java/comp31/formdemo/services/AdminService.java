package comp31.formdemo.services;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import comp31.formdemo.model.Employee;
import comp31.formdemo.repositories.Accounts;

@Service
public class AdminService{
    Logger logger = LoggerFactory.getLogger(AdminService.class);

    public AdminService() {
        super();    
    }
    //gathers all employees and puts them in a Arraylist
    public ArrayList<Employee> findAllEmployees(Accounts accounts) {
        ArrayList<Employee> employeeList = new ArrayList<>();
          for (Employee employee : accounts) {
            employeeList.add(employee);
          }
        return employeeList;
        }
//this loops through the provided accounts list and only grabs the employees with the requested 
// department and puts them in a new Arraylist
    public ArrayList<Employee> findEmployeesByDepartment(Accounts accounts, String department) {
        ArrayList<Employee> employeeList = new ArrayList<>();
          for (Employee employee : accounts) 
          {
            if(employee.getDepartment().equals(department))
            {
            employeeList.add(employee);
            }
          }
        return employeeList;
        }
//finds all departments and puts it in a HashSet to prevent duplicates
    public Set<String> findAllDepartments(Accounts accounts) {
            Set<String> depSet = new HashSet<>();
            for (Employee employee : accounts) {
            depSet.add(employee.getDepartment());
            }
        return depSet;
        }
}
