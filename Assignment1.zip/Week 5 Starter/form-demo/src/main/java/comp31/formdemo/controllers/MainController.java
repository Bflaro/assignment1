package comp31.formdemo.controllers;

import java.util.ArrayList;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import comp31.formdemo.model.Employee;
import comp31.formdemo.services.AdminService;
import comp31.formdemo.services.LoginService;

@Controller
public class MainController {

    Logger logger = LoggerFactory.getLogger(MainController.class);

    LoginService loginService;
    AdminService adminService;
    ArrayList<Employee> employees;
    Set<String> depts;

    //main controller initilizes users into an Employee arraylist
    public MainController(LoginService loginService, AdminService adminService) {
        this.loginService = loginService;
        this.adminService = adminService;

        //Creates initial list of employees
        loginService.addEmployee("Joe","orders","Joe");
        loginService.addEmployee("Moe","orders","Moe");
        loginService.addEmployee("Mary","sales","Mary");
        loginService.addEmployee("Jane","sales","Jane");
        loginService.addEmployee("Josh","admin","Josh");
        loginService.addEmployee("Bill","admin","Bill");

    }

    //creates path to initial page
    @GetMapping("/")
    String getRoot(Model model) {
        logger.info("---- At root.");
        Employee employee = new Employee(); // Create backing object and
        model.addAttribute("employee", employee); // send it to login form
        return "login-form";
    }

    //when the login button is pressed this validates the login and finds the departments to be initially shown
    @PostMapping("/login")
    public String getForm(Employee employee, Model model) {
        String loginPage;
        loginPage = loginService.validateCurrentEmployee(employee);

        depts = loginService.findAllDepartments();
        model.addAttribute("departments", depts);

       return loginPage;
    }

    //This sets up the textbox info for the new employee
    @GetMapping("/admin")
    public String getRegister(Model model)
    {   
        model.addAttribute("departments", depts);
        model.addAttribute("employee", new Employee());
        return "departments/admin";
    }

    //this adds the new employee to the list
    @PostMapping("/admin")
    public String postRegister(Employee employee) {
        loginService.addEmployee(employee);
       return "redirect:/admin";
    }

    //looks though and determines which employees are to be shown
    @GetMapping("/showEmp")
    public String RegisterEmpTable(@RequestParam(value = "departments", required = false) String selectedDepartment, Model model)
    {
        if(employees != null) { employees.clear(); } // Clears the table each time the button is pressed to avoid duplicates
        if(selectedDepartment == null){ selectedDepartment = ""; } // Takes care of the selectedDepartment = null (user presses see table twice)

        // looks through each of the 4 roles and determines what employees are shown
        if(selectedDepartment.equals("admin"))
            { employees = loginService.findEmployeesByDepartment("admin"); }
        else if(selectedDepartment.equals("sales"))
            { employees = loginService.findEmployeesByDepartment("sales"); }
        else if(selectedDepartment.equals("orders"))
            { employees = loginService.findEmployeesByDepartment("orders"); }
        else if(selectedDepartment.equals("AllEmployees"))
            { employees = loginService.findAllEmployees(); }
        else
            { employees.clear(); }

        model.addAttribute("employee", new Employee());
        model.addAttribute("employees", employees);
        model.addAttribute("departments", depts);
        return "departments/admin";
    }
    //adds selected employees to the list
    @PostMapping("/showEmp")
    public String postEmpTable(Employee employee, Model model) {

        model.addAttribute("employee", new Employee());
        return "departments/admin";
    }
}
