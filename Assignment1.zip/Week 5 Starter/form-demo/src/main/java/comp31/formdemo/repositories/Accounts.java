package comp31.formdemo.repositories;

import java.util.ArrayList;

import org.springframework.stereotype.Component;

import comp31.formdemo.model.Employee;

@Component
public class Accounts extends ArrayList<Employee> {

    public Accounts()
    {
        super();
    }
    //finds an employee by going through a loop until the provided userID matches or comes up null
    public Employee findByUserId(String userId) {
        for (Employee employee : this) {
            if (employee.getUserId().equals(userId))
                return employee;
        }
        return null;
    }

}
