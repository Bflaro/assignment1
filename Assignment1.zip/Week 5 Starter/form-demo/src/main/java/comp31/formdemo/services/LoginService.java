package comp31.formdemo.services;

import java.util.ArrayList;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import comp31.formdemo.model.Employee;
import comp31.formdemo.repositories.Accounts;

@Service
public class LoginService {

    Logger logger = LoggerFactory.getLogger(LoginService.class);

    Accounts accounts;
    AdminService adminService;

    public LoginService() {
        this.accounts = new Accounts();
        this.adminService = new AdminService();

    }
// adds a new new employee to the accounts list manualy by inputing each String 
    public void addEmployee(String userId, String department, String password) {
        logger.info("Adding user: " + userId);
        Employee employee = new Employee(userId, department, password);
        accounts.add(employee);
    } 
// adds a new employee by inserting the employee object directly
    public void addEmployee(Employee employee) {
        accounts.add(employee);
    }
//calls the Accounts.java findByuser method
    public Employee findByUserId(String userId) {
        return accounts.findByUserId(userId);
    }
//calls the AdminService.java findAllEmployees method
    public ArrayList<Employee> findAllEmployees() 
    {
        return adminService.findAllEmployees(accounts);
    }
//calls the AdminService.java findAllDepartments method
    public Set<String> findAllDepartments()
    {
        return adminService.findAllDepartments(accounts);
    }
//calls the AdminService.java findEmployeesByDepartment method
    public ArrayList<Employee> findEmployeesByDepartment(String department) 
    {
        return adminService.findEmployeesByDepartment(accounts, department);
    }
// this looks through the login attemps userId and password and determines if it is valid 
// if so, it will look into that users department to see which page to direct them else it will reload the login page
     public String validateCurrentEmployee(Employee employee)
    {
        Employee currentUser = findByUserId(employee.getUserId());
        String returnPage;
        if (currentUser == null) {
            returnPage = "login-form";
        } 
        else {
            if(currentUser.getDepartment() == null){  returnPage = "login-form";  }

            else{
                if(employee.getPassword().equals(currentUser.getPassword()))
                    {  returnPage = "departments/" + currentUser.getDepartment();  }

                else{  returnPage = "login-form";  }
            }    
        }
        return returnPage;
    }

}
